package testExecution;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import POM.FlightRoundTrip;
import POM.OneWaySearchFlight;
import POM.searchFactory;
import util.Base;
import util.DataDrivenExcel;
import util.Excel;


public class ExecuteFlightRoundTrip extends Base
{

		
	
		@Test(priority=1,dataProvider="FlightOneWayData")
		public void Flight(String  source,
				String destination,	
				String departureDate,
				String Adults,
				String children,
				String infants,
				String title,
				String firstName,
				String LastName,
				String viacash
				,String MobNo
				,String EmailId) 
		{
			FlightRoundTrip roundTripFlight=new FlightRoundTrip(driver);
			roundTripFlight.RoundTripSearch(source, destination, departureDate, Adults, children, infants, title, firstName, LastName, viacash, MobNo, EmailId);
	
	
		}
		
	@DataProvider
		public Object[][] FlightOneWayData() throws Exception
		{
			Object data[][]=excel.MyDataProvider("FlightOneWay", 12);
			System.out.println("HII");
			return data;
		}

}
