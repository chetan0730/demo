package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebElement;

public class OneWaySearchFlight  extends Factory{


	public OneWaySearchFlight(WebDriver iDriver)
	{
		super(iDriver);

	}
	public void OneWaySearch(String  source,
			String destination,	String departureDate,String Adults,String children,	String infants,String title,String firstName,String LastName,String viacash,String MobNo,String Email	)  
	{

		WebDriverWait wt=new WebDriverWait(driver, 20);
		System.out.println("Hi2");
	//	Thread.sleep(3000);
driver.findElement(By.xpath("//label[@for='one-way']")).click();
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_From1")));
		driver.findElement(property.getElement("E_From1")).clear();
		driver.findElement(property.getElement("E_From1")).sendKeys(source);
	

		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_From1_dropDown")));


		driver.findElement(property.getElement("E_dropDown1")).click();
		
		driver.findElement(property.getElement("E_To1")).clear();
		driver.findElement(property.getElement("E_To1")).sendKeys(destination);
	
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_To1_dropDown")));
		
		driver.findElement(property.getElement("E_dropDown2")).click();


		WebElement calender=	driver.findElement(property.getElement("E_DatePick1"));
		action.moveToElement(calender).click(calender).perform();


		WebElement toggle=	driver.findElement(property.getElement("E_Toggle"));
		action.moveToElement(toggle).click(toggle).perform();


		driver.findElement(property.getElement("E_DeptDate")).click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {

			e1.printStackTrace();
		}
		
		
		
		//((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(By.xpath("//a[@class='show-more closed']")));
		
		driver.findElement(property.getElement("E_SearchFlight_Btn")).click();	


		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='lowFares-box-container cheap-box-container']//div[6]")));
		driver.findElement(By.xpath("//div[@class='lowFares-box-container cheap-box-container']//div[6]")).click();

		driver.findElement(property.getElement("E_BookBtn")).click();	
		System.out.println("button");

		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		driver.manage().window().maximize();
		JavascriptExecutor js = (JavascriptExecutor)driver;

		Select select =new Select(driver.findElement(property.getElement("E_Title_Drop_Down1")));
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"adult1Title\"]/option[2]")));

		driver.findElement(property.getElement("E_Adult_F_Name1")).clear();
		driver.findElement(property.getElement("E_Adult_F_Name1")).sendKeys(firstName);
		driver.findElement(property.getElement("E_Adult_L_Name1")).clear();
		driver.findElement(property.getElement("E_Adult_L_Name1")).sendKeys(LastName);
		select.selectByVisibleText("Mr");

		driver.findElement(property.getElement("E_Mob_no")).clear();
		driver.findElement(property.getElement("E_Mob_no")).sendKeys(MobNo);
		driver.findElement(property.getElement("E_Email")).clear();
		driver.findElement(property.getElement("E_Email")).sendKeys(Email);
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
			
		}
		/*if(driver.findElement(property.getElement("E_Continue")).isDisplayed())
		{
			driver.findElement(property.getElement("E_Continue")).click();
		}*/
		//System.out.println("clicked");

		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("voucherValidate")));
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"makePayCTA\"]")));
	//	new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_MakePayment")));
		new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"makePayCTA\"]")));
	//	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(property.getElement("E_MakePayment")));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"makePayCTA\"]")));
	//	((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(property.getElement("E_MakePayment")));
				try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		System.out.println("clicked");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		
		new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"confirmProceedPayBtn\"]/span[2]")));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id=\"confirmProceedPayBtn\"]/span[2]")));
		//	driver.findElement(property.getElement("E_Pay")).click();
	//	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(property.getElement("E_Pay")));
		//((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(property.getElement("E_Pay")));
		
		
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"stp2Cont\"]/div[1]/div/div[1]/div[1]")));
		
	
		driver.findElement(property.getElement("E_Home")).click();	
		System.out.println("clicked1");

	}
}
