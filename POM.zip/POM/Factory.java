package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import util.LoadProperty;


public class Factory {
	public	WebDriver driver;
	public	LoadProperty property;
	public Actions action;
	public Factory(WebDriver iDriver)
	{
		this.driver=iDriver;
		property=new LoadProperty(".\\OR.property");
		action = new Actions(iDriver);
	}
}
