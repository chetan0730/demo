package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class SignUpFactory extends Factory {
	
	public SignUpFactory(WebDriver iDriver) 
	{
		super(iDriver);
	}

	public void SIGNUP(String userName,String PassWord,String name, String mobNo) throws Exception
	{
		//String dataA[]=data.split(",");
		driver.findElement(property.getElement("E_SIGNIN")).click();
		WebDriverWait wt=new WebDriverWait(driver, 20);
		wt.until(ExpectedConditions.visibilityOf(driver.findElement(property.getElement("E_SIGNUP_BTN"))));
		driver.findElement(property.getElement("E_SIGNUP_BTN")).click();
		driver.findElement(property.getElement("E_EM_SIGNUP")).clear();
		driver.findElement(property.getElement("E_EM_SIGNUP")).sendKeys(userName);
		driver.findElement(property.getElement("E_PWD_SIGNUP")).clear();
		driver.findElement(property.getElement("E_PWD_SIGNUP")).sendKeys(PassWord);
		driver.findElement(property.getElement("E_NAME_SIGNUP")).clear();
		driver.findElement(property.getElement("E_NAME_SIGNUP")).sendKeys(name);
		driver.findElement(property.getElement("E_MOB_SIGNUP")).clear();
		driver.findElement(property.getElement("E_MOB_SIGNUP")).sendKeys(mobNo);
		driver.findElement(property.getElement("E_CREATE_ACC")).click();
		//driver.findElement(property.getElement("E_SIGNUP_BTN")).click();
		
		
		try {
			new WebDriverWait(driver, 10).until(ExpectedConditions.invisibilityOf(driver.findElement(By.id("signUpValidate"))));
			new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Cancellations')]")));
		}
		catch(TimeoutException T)
		{
			throw new AssertionError("sighnup failedFailed");
		}
		// Assert.assertEquals(driver.getTitle(), "Book Flights,Hotels,Bus and Holiday Packages Online-Via.com");
		/*if(driver.getTitle().equals("Book Flights,Hotels,Bus and Holiday Packages Online-Via.com"))
		{
			System.out.println("Login Done");
			driver.findElement(By.linkText("Logout")).click();
		}
		else
		{
			System.out.println("Login Fail");
		}*/
		
		
	}
}
