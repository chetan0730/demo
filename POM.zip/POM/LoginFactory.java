package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;



public class LoginFactory extends Factory {
	public LoginFactory(WebDriver iDriver)
	{
		super(iDriver);
	}

	public void Login(String username,String Password)
	{
		driver.findElement(property.getElement("E_LOGIN")).click();
		driver.findElement(property.getElement("E_EM")).clear();
		driver.findElement(property.getElement("E_EM")).sendKeys(username);;
		driver.findElement(property.getElement("E_PWD")).clear();
		driver.findElement(property.getElement("E_PWD")).sendKeys(Password);;
		driver.findElement(property.getElement("E_LG")).click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	try {
		new WebDriverWait(driver, 10).until(ExpectedConditions.invisibilityOf(driver.findElement(property.getElement("E_LG"))));
		new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Cancellations')]")));
	}
	catch(TimeoutException T)
	{
		throw new AssertionError("Login Failed");
	}
		
		
		
		//
	/*	if(driver.getTitle().equals("Book Flights,Hotels,Bus and Holiday Packages Online-Via.com"))
		{
			System.out.println("Login Done");
			driver.findElement(By.linkText("Logout")).click();
		}
		else
		{
			System.out.println("Login Fail");
		}*/
	}
}
