package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class BusBooking extends Factory{
	
	public BusBooking(WebDriver iDriver) 
	{
		super(iDriver);
	}
		public void BusDetails(String name, String age, String contact, String email )throws Exception {
	Select select=new Select(driver.findElement(property.getElement("E_TitleBus")));
	select.selectByVisibleText("Miss");
	Thread.sleep(1000);
	driver.findElement(property.getElement("E_nameBus")).clear();
	driver.findElement(property.getElement("E_nameBus")).sendKeys(name);
	Thread.sleep(1000);
	driver.findElement(property.getElement("E_ageBus")).clear();
	driver.findElement(property.getElement("E_ageBus")).sendKeys(age);
	Thread.sleep(1000);
	driver.findElement(property.getElement("E_mobileBus")).clear();
	driver.findElement(property.getElement("E_mobileBus")).sendKeys(contact);
	Thread.sleep(1000);
	driver.findElement(property.getElement("E_emailBus")).clear();
	driver.findElement(property.getElement("E_emailBus")).sendKeys(email);
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"offerCodeLabel\"]/div[2]")).click();
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"read_terms_label\"]")).click();
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"makePayCTA\"]")).click();
	Thread.sleep(5000);
	//driver.findElement(property.getElement("E_makePaymentBus")).click();
	driver.findElement(By.xpath("//*[@id=\"confirmProceedPayBtn\"]/span[2]")).click();
	Thread.sleep(5000);
	driver.findElement(By.xpath("//div[@class='container']//a[@class='viaLogo hideFromCustomer']")).click();
	
	
		}
	}