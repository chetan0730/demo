package POM;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import POM.Factory;

public class FlightRoundTrip  extends Factory{
	

	public FlightRoundTrip(WebDriver iDriver)
	{
		super(iDriver);
	
	}
	public void RoundTripSearch(String source, String destination, String departureDate, String Adults, String children, String infants, String title, String firstName, String LastName, String viacash, String MobNo, String EmailId	)   
	{	
		WebDriverWait wt=new WebDriverWait(driver, 20);
		driver.manage().window().maximize();

		System.out.println("Hi2");
		
		//driver.findElement(By.xpath("//label[@for='round-trip']")).click();
		driver.findElement(property.getElement("E_RoundTripTitle")).click();
	
		driver.findElement(property.getElement("E_From1")).clear();
		driver.findElement(property.getElement("E_From1")).sendKeys(source);
		try 
		{
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_From1_dropDown")));
		}
		catch(TimeoutException T)
		{
			throw new AssertionError("Source ,city not found");
		}
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-1']/li")));
		
		
		driver.findElement(property.getElement("E_dropDown1")).click();
		
		driver.findElement(property.getElement("E_To1")).clear();
		driver.findElement(property.getElement("E_To1")).sendKeys(destination);
		try 
		{
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_To1_dropDown")));
		}
		catch(TimeoutException T)
		{
			throw new AssertionError("Destination ,city not found");
		}
	new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-2']/li")));
		
		;
	driver.findElement(property.getElement("E_dropDown2")).click();

		
	WebElement calender=	driver.findElement(property.getElement("E_DatePick1"));
	action.moveToElement(calender).click(calender).perform();
	
	
		WebElement toggle=	driver.findElement(property.getElement("E_Toggle"));
		action.moveToElement(toggle).click(toggle).perform();
	

		driver.findElement(property.getElement("E_DeptDate")).click();
		
	
		driver.findElement(By.xpath("//div[@class='element return-element']//div[@class='calendar-icon']")).click();


		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOf(driver.findElements(By.xpath("//*[@data-month='5']//*[@data-date='30']")).get(1)));
		driver.findElements(By.xpath("//*[@data-month='5']//*[@data-date='30']")).get(1).click();


if(driver.findElement(property.getElement("AirIndia_Oneway")).isDisplayed()==false)
{
	driver.findElement(property.getElement("Airline_Oneway")).click();
}

driver.findElement(property.getElement("AirIndia_Oneway")).clear();
driver.findElement(property.getElement("AirIndia_Oneway")).sendKeys("AirIndia");

new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//ul[@id='ui-id-13']/li[1]")));
driver.findElement(By.xpath("//ul[@id='ui-id-13']/li[1]")).click();

driver.findElement(property.getElement("E_SearchFlight_Btn")).click();	

new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_Itineraries")));		
driver.findElement(property.getElement("E_Itineraries")).click();	
driver.findElement(property.getElement("E_Baggage")).click();	
driver.findElement(property.getElement("E_Meal")).click();	


driver.findElement(property.getElement("E_Flight1btn")).click();
driver.findElement(property.getElement("E_Flight2btn")).click();
System.out.println("button");



new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='bookCTA return']")));
new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='bookCTA return']")));
 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(By.xpath("//div[@class='bookCTA return']")));

JavascriptExecutor js = (JavascriptExecutor)driver;

Select select =new Select(driver.findElement(property.getElement("E_Title_Drop_Down1")));
new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"adult1Title\"]/option[2]")));

driver.findElement(property.getElement("E_Adult_F_Name1")).clear();
	driver.findElement(property.getElement("E_Adult_F_Name1")).sendKeys(firstName);
	driver.findElement(property.getElement("E_Adult_L_Name1")).clear();
	driver.findElement(property.getElement("E_Adult_L_Name1")).sendKeys(LastName);
	//select.selectByVisibleText("Mr");
	if(title.contains("Mr"))
	{
	select.selectByVisibleText("Mr");
	}
	else if(title.contains("Miss"))
	{
	select.selectByVisibleText("Miss");
	}
	
	
	driver.findElement(property.getElement("E_Mob_no")).clear();
	driver.findElement(property.getElement("E_Mob_no")).sendKeys(MobNo);
	driver.findElement(property.getElement("E_Email")).clear();
	driver.findElement(property.getElement("E_Email")).sendKeys(EmailId);
	
	
	new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@id='makePayCTA']")));
	new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='makePayCTA']")));
	 ((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(By.xpath("//button[@id='makePayCTA']")));
	
	 try {
			new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"confirmProceedPayBtn\"]/span[2]")));
			}catch(TimeoutException T)
			{
				throw new AssertionError(" Failed to load next page due to invalid data");
			}
	 new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_Pay")));		
		driver.findElement(property.getElement("E_Pay")).click();	
		System.out.println("clicked");
	
	
		driver.navigate().to("https://in.via.com/");
	
	
	

	}
}
