package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.WebElement;

public class OneWaySearchFlight  extends Factory{


	public OneWaySearchFlight(WebDriver iDriver)
	{
		super(iDriver);

	}
	public void OneWaySearch(String  source,
			String destination,	String departureDate,String Adults,String children,	String infants,String title,String firstName,String LastName,String viacash,String MobNo,String Email	)  
	{

		WebDriverWait wt=new WebDriverWait(driver, 20);
		System.out.println("Hi2");
		driver.manage().window().maximize();
		
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_OneWayTitle")));
		driver.findElement(property.getElement("E_OneWayTitle")).click();
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_From1")));
		driver.findElement(property.getElement("E_From1")).clear();
		driver.findElement(property.getElement("E_From1")).sendKeys(source);
		try 
		{
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_From1_dropDown")));
		}
		catch(TimeoutException T)
		{
			throw new AssertionError("Source ,city not found");
		}
	

		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_From1_dropDown")));


		driver.findElement(property.getElement("E_dropDown1")).click();
		
		driver.findElement(property.getElement("E_To1")).clear();
		driver.findElement(property.getElement("E_To1")).sendKeys(destination);
		
		try 
		{
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_To1_dropDown")));
		}
		catch(TimeoutException T)
		{
			throw new AssertionError("Destination ,city not found");
		}
		
		
		driver.findElement(property.getElement("E_dropDown2")).click();


		WebElement calender=	driver.findElement(property.getElement("E_DatePick1"));
		action.moveToElement(calender).click(calender).perform();


		WebElement toggle=	driver.findElement(property.getElement("E_Toggle"));
		action.moveToElement(toggle).click(toggle).perform();


		driver.findElement(property.getElement("E_DeptDateOW")).click();
	
	
		if(driver.findElement(property.getElement("AirIndia_Oneway")).isDisplayed()==false)
		{
			driver.findElement(property.getElement("Airline_Oneway")).click();
		}
		
		driver.findElement(property.getElement("AirIndia_Oneway")).clear();
		driver.findElement(property.getElement("AirIndia_Oneway")).sendKeys("Airindia");
	

		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_AirLineDropDown")));
		driver.findElement(property.getElement("E_AirLineDropDown")).click();	
		driver.findElement(property.getElement("E_SearchFlight_Btn")).click();	

		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_Itineraries")));		
		driver.findElement(property.getElement("E_Itineraries")).click();	
		driver.findElement(property.getElement("E_Baggage")).click();	
		driver.findElement(property.getElement("E_Meal")).click();	
	
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_BookBtn")));
		driver.findElement(property.getElement("E_BookBtn")).click();	
		System.out.println("button");

	
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_Title_Drop_Down1")));	
		Select select =new Select(driver.findElement(property.getElement("E_Title_Drop_Down1")));
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_Title_Drop_Down1")));		
	
		driver.findElement(property.getElement("E_Adult_F_Name1")).clear();
		driver.findElement(property.getElement("E_Adult_F_Name1")).sendKeys(firstName);
		driver.findElement(property.getElement("E_Adult_L_Name1")).clear();
		driver.findElement(property.getElement("E_Adult_L_Name1")).sendKeys(LastName);
		if(title.contains("Mr"))
		{
		select.selectByVisibleText("Mr");
		}
		else if(title.contains("Miss"))
		{
		select.selectByVisibleText("Miss");
		}
 
		driver.findElement(property.getElement("E_Mob_no")).clear();
		driver.findElement(property.getElement("E_Mob_no")).sendKeys(MobNo);
		try 
		{
			new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_Mob_no")));
		}
		catch(TimeoutException T)
		{
			throw new AssertionError("Invalid Mobile Number");
		}
		driver.findElement(property.getElement("E_Email")).clear();
		driver.findElement(property.getElement("E_Email")).sendKeys(Email);
		
	
		
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("voucherValidate")));

		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_MakePayment")));		
	
		new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"makePayCTA\"]")));
	
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(property.getElement("E_MakePayment")));
			
		
		System.out.println("clicked");
		
		
		try {
		new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"confirmProceedPayBtn\"]/span[2]")));
		}catch(TimeoutException T)
		{
			throw new AssertionError(" Failed to load next page due to invalid data");
		}
		
		
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", driver.findElement(property.getElement("E_Pay")));
			new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_VisibleCreditCard")));
		
		driver.findElement(property.getElement("E_Home")).click();	
		System.out.println("clicked1");

	}
}
