package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BusOneWay extends Factory{
	
	public BusOneWay(WebDriver iDriver) 
	{
		super(iDriver);
	}
		
	public void BusOneWaySearch(String source,String destination) throws Exception
	{
		JavascriptExecutor busScroll = (JavascriptExecutor) driver;

		driver.manage().window().maximize();
		Actions action= new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		driver.findElement(property.getElement("E_Buses")).click();
		
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_From")));	
		
		driver.findElement(property.getElement("E_From")).click();
		driver.findElement(property.getElement("E_From")).clear();
		driver.findElement(property.getElement("E_From")).sendKeys(source);
		
		try 
		{
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_SrcDropDown")));
		}
		catch(TimeoutException T)
		{
			throw new AssertionError("Source ,city not found");
		}
		
		
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_SrcDropDown")));
		
	WebElement E=driver.findElement(By.xpath("//ul[@id='ui-id-1']/li//*[contains(text(),'"+source+"')]"));  
			action.moveToElement(E).click(E).perform();
			
			driver.findElement(property.getElement("E_To")).clear();
		driver.findElement(property.getElement("E_To")).sendKeys(destination);
		
		try 
		{
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_DstDropDown")));
		}
		catch(TimeoutException T)
		{
			throw new AssertionError("Destination ,city not found");
		}
		
	
		
		driver.findElement(property.getElement("E_DstDropDown")).click();
		
		
			new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_departureDate")));	
		WebElement calender=	driver.findElement(property.getElement("E_departureDate"));
		action.moveToElement(calender).click(calender).perform();
		
		WebElement toggle=	driver.findElement(property.getElement("E_ToggleBus"));
		action.moveToElement(toggle).click(toggle).perform();
		
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_DeptDatebus")));	
		driver.findElement(property.getElement("E_DeptDatebus")).click();
	
		driver.findElement(property.getElement("E_SearchBuses")).click();
		
	
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(property.getElement("E_ShaktiTravels")));	
	
		driver.findElement(property.getElement("E_ShaktiTravels")).click();
		
		
		driver.findElement(property.getElement("E_SelectSeats")).click();
	
		busScroll.executeScript("window.scrollBy(0,200)");
		Select select = new Select(driver.findElement(property.getElement("E_BoardingPtRoundTrip")));
		select.selectByValue("215168");
		Select select1 = new Select(driver.findElement(property.getElement("E_DroppingPtRoundTrip")));
		select1.selectByValue("81991");
		driver.findElement(property.getElement("E_proceedBus")).click();
	
			}	
	}

	

