package testExecution;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import util.Base;
import util.DataDrivenExcel;
import util.Excel;

public class ExecuteLogin extends Base
{

		
	
		@Test(priority=1,dataProvider="LoginData")
		public void LoginTest(String UN,String PWD) 
		{
			LF.Login(UN,PWD);
		 
		} 
		
	@DataProvider
		public Object[][] LoginData() throws Exception
		{
			Object data[][]=excel.MyDataProvider("Login", 2);
			return data;
		}

}
