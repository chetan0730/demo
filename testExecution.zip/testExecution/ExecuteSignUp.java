package testExecution;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


import util.Base;
import util.DataDrivenExcel;
import util.Excel;

public class ExecuteSignUp extends Base
{

		@Test(priority=1,dataProvider="SignUpData")
		  public void SignupTest(String userName,String passWord,String name,String mobNo) throws Exception
		  {
			
			 SF.SIGNUP(userName,passWord,name,mobNo);
			 
		  }

		
	@DataProvider
		public Object[][] SignUpData() throws Exception
		{
			Object data[][]=excel.MyDataProvider("SignUp", 4);
			return data;
		}
	
}
