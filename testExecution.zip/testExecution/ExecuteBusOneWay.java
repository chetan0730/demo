package testExecution;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import POM.BusOneWay;
import util.Base;
import POM.BusBooking;

public class ExecuteBusOneWay extends Base
{

	/*@BeforeMethod
	public void beforeMethod()
	{
		driver.get("https://in.via.com/bus-tickets");
	}*/
		@Test(priority=1, dataProvider="BusData")
		
		  public void BusOneWayTest(String source,String destination) throws Exception
		  {
			BusOneWay BOneWay = new BusOneWay(driver);

			BOneWay.BusOneWaySearch(source,destination); 
		  }
	
		
	@DataProvider
		public Object[][] BusData() throws Exception
		{
			Object data[][]=excel.MyDataProvider("BusOneWay",2);
			return data;
		}
	
	@Test(priority=2, dataProvider="Details")
	
	  public void BusBookingTest(String name, String age, String contact, String email) throws Exception
	  {
		BusBooking bus = new BusBooking(driver);

		bus.BusDetails(name, age, contact, email);
	  }

	
@DataProvider
	public Object[][] Details() throws Exception
	{
		Object data1[][]=excel.MyDataProvider("BusTravelDetails",4);
		return data1;
	}
	
}
