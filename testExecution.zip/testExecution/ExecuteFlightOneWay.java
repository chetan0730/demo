package testExecution;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import POM.FlightRoundTrip;
import POM.OneWaySearchFlight;

import util.Base;
import util.DataDrivenExcel;
import util.Excel;


public class ExecuteFlightOneWay extends Base
{

		@BeforeMethod
		public void beforeMethod()
		{
			driver.get("https://in.via.com/");
		}
	
		@Test(priority=1,dataProvider="FlightOneWayData")
		public void Flight(String  source,
				String destination,	
				String departureDate,
				String Adults,
				String children,
				String infants,
				String title,
				String firstName,
				String LastName,
				String viacash
				,String MobNo
				,String EmailId) 
		{
			OneWaySearchFlight OneWFlight=new OneWaySearchFlight(driver);
			OneWFlight.OneWaySearch(source, destination, departureDate, Adults, children, infants, title, firstName, LastName, viacash, MobNo, EmailId);
		
		}
	/*	@Test(priority=1,dataProvider="LoginData")
		public void LoginTest(String UN,String PWD) 
		{
			LF.Login(UN,PWD);
		 
		} */
		
/*	@DataProvider
		public Object[][] LoginData() throws Exception
		{
			Object data[][]=excel.MyDataProvider("Login", 2);
			return data;
		}*/
		
	@DataProvider
		public Object[][] FlightOneWayData() throws Exception
		{
			Object data[][]=excel.MyDataProvider("FlightOneWay", 12);
			System.out.println("HII");
			return data;
		}

}
