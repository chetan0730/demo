package testExecution;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import POM.searchFactory;
import util.Base;
import util.DataDrivenExcel;
import util.Excel;

public class Execute extends Base
{
//	public Excel excel=new Excel("/MakeMyTrip/Book1.xlsx");
		@Test(priority=1,dataProvider="SignUpData")
		  public void SignupTest(String userName,String passWord,String name,String mobNo) throws Exception
		  {
			//System.out.println(userName);
			 SF.SIGNUP(userName,passWord,name,mobNo);
			 
		  }
	/*  public void SignupTest() throws Exception
	  {
		  SF.SIGNUP("prashar.vaishnavi@gmail.com,Vaishnavi@123,Vaishnavi,7062310377");
		 boolean A= Key.verifyOnInVisibilty(7,By.id("ch_signup_btn") , "SIGNUP");
		 System.out.println(A);
		 
	  }*/
		/*@Test(priority=2,dataProvider="LoginData")
		public void LoginTest(String UN,String PWD) 
		{
			LF.Login(UN,PWD);
		 
		} */
		
	@DataProvider
		public Object[][] SignUpData() throws Exception
		{
			Object data[][]=excel.MyDataProvider("Sheet1", 4);
			return data;
		}
	/*	@Test(priority=3)
		public void searchTest() 
		{
			searchFactory sf=new searchFactory(driver);
			sf.search("ABC");
			
		}*/
}
