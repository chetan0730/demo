package flight;

import org.openqa.selenium.WebDriver;

import POM.Factory;

public class OneWaySearchFlight  extends Factory{

	public OneWaySearchFlight(WebDriver iDriver)
	{
		super(iDriver);
	}
	
}
